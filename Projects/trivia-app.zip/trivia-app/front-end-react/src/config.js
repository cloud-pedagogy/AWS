module.exports = {
  WebsocketEndpoint: 'REPLACE_WITH_WWS_ENDPOINT'
};
