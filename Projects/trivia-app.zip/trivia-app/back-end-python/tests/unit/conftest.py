import os

os.environ["TABLE_NAME"] = "mock-table"
os.environ["APIGW_ENDPOINT"] = "https://mock-uri/"
