<nav class="navbar fixed-top navbar-expand-sm navbar-dark bg-dark">
    <a class="navbar-brand" href="/index.php">Pet Adoption Website</a>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
        <a class="nav-item nav-link active" href="/cats.php">Cats</a>
        <a class="nav-item nav-link active" href="/dogs.php">Dogs</a>
        <a class="nav-item nav-link active" href="/adopt.php">Adoption Application</a>
        </div>
    </div>
</nav>