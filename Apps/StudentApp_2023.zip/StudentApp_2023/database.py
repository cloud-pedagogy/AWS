"Database layer - next time use SQLAlchemy"
import mysql.connector
import config

def list_students():
    "Select all the students from the database"
    conn = get_database_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""SELECT id, object_key, full_name, location, job_title, badges
        FROM student
        ORDER BY full_name desc""")
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    return result

def load_student(student_id):
    "Select one the student from the database"
    conn = get_database_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""SELECT id, object_key, full_name, location, job_title, badges
        FROM student
        WHERE id = %(emp)s;""", {'emp': student_id})
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result

def add_student(object_key, full_name, location, job_title, badges):
    "Add an student to the database"
    conn = get_database_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""INSERT INTO student (object_key, full_name, location, job_title, badges)
     VALUES (%s, %s, %s, %s, %s);""", (object_key, full_name, location, job_title, badges))
    conn.commit()
    cursor.close()
    conn.close()

def update_student(student_id, object_key, full_name, location, job_title, badges):
    "Update an student to the database"
    conn = get_database_connection()
    cursor = conn.cursor(dictionary=True)


    if object_key:
        cursor.execute("""
            UPDATE student SET
            object_key=%s, full_name=%s, location=%s, job_title=%s, badges=%s
            WHERE id = %s;
         """, (object_key, full_name, location, job_title, badges, student_id))
    else:
        # if no object key is supplied, don't update it
        cursor.execute("""
            UPDATE student SET
            full_name=%s, location=%s, job_title=%s, badges=%s
            WHERE id = %s;
         """, (full_name, location, job_title, badges, student_id))

    conn.commit()
    cursor.close()
    conn.close()

def delete_student(student_id):
    "Delete an student."
    conn = get_database_connection()
    cursor = conn.cursor()
    cursor.execute("""DELETE FROM student WHERE id = %(emp)s;""", {'emp': student_id})
    conn.commit()
    cursor.close()
    conn.close()

def get_database_connection():
    "Build a database connection"
    conn = mysql.connector.connect(user=config.DATABASE_USER, password=config.DATABASE_PASSWORD,
                                   host=config.DATABASE_HOST,
                                   database=config.DATABASE_DB_NAME,
                                   use_pure=True) # see https://bugs.mysql.com/90585
    return conn
