Resources for: Building and Troubleshooting a Serverless Web Application Hands-On Lab.
